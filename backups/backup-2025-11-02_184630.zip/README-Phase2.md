## AST - Estado y Siguientes Pasos (Fase 2)

Resumen rápido
- Rama de trabajo: `starscript/backup-2025-10-31_145027`
- Estado: Fase 1 completada (MVP transpiler + Translator UI). Parser MVP implementado a mano en `src/lib/star-parser/index.ts`.

Objetivo inmediato (Fase 2)
- Decidir y ejecutar una estrategia para el parser/AST:
  - Opción A: Generar parser desde gramática (`grammar.pegjs`) usando `peggy` (recomendado a largo plazo).
  - Opción B: Extender el parser hand-written ya presente (`index.ts`) para cubrir más constructs.

Archivos clave
- `src/lib/star-transpiler.ts` — traductor heurístico Pine ↔ Star (MVP).
- `src/lib/star-parser/index.ts` — parser hand-written MVP (AST extractor).
- `src/lib/star-parser/grammar.pegjs` — gramática PEG (lista para generar parser con `peggy`).
- `src/components/BottomPanel.tsx` — UI Translator integrado.

Comandos útiles
- Autenticar `gh` (web flow):
  ```powershell
  gh auth login --hostname github.com --web
  gh auth status
  ```
- Ejecutar tests:
  ```powershell
  npm ci
  npm test
  ```
- Generar parser (si `peggy` instalado):
  ```powershell
  npm run build:parser
  ```

Propuesta de trabajo inmediato (plan de tasks)
1. Validar tests existentes y cobertura del parser MVP.
2. Aumentar tests de parser para casos de expresión, llamadas, arrays y precedencia.
3. Si se prefiere `peggy`: añadir step en CI para intentar generar parser en runner; validar generación en CI.
4. Documentar API del AST y añadir ejemplos de uso en `tests/`.

Si necesitas que continúe, puedo:
- crear la rama `starscript/phase2-parser` con plantillas de tests y tareas; o
- comenzar a añadir tests para el parser MVP; o
- preparar la integración de `peggy` en CI.

Contacto
- Repo actual: `https://github.com/gapontegroupgith-cmd/AST-01-11-2025`

---
Generado automáticamente por el asistente para resumir el estado y pasos de Fase 2.
