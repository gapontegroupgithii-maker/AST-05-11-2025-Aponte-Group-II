# Phase 2 Plan — Parser & AST (short plan)

Objetivo: Completar la integración de la gramática PEG con generación automática y dejar una transición segura desde el parser hecho a mano a un parser generado por Peggy si se decide migrar.

Pasos próximos (priorizados):

1. Estabilizar la gramática en `src/lib/star-parser/grammar.pegjs` y mantener la suite de tests `tests/parser` como la fuente de verdad.
2. Mantener el parser hand‑written (`src/lib/star-parser/index.ts`) como fallback y referencia. Añadir adaptadores si el AST generado difiere en forma.
3. En CI: generar parser con `npx peggy` y validar compatibilidad (ya añadido en workflow opcional). Fallar el job si hay mismatch.
4. Revisión de PR y merge a `main` cuando la gramática sea estable y los tests pasen.
5. (Opcional) Añadir source locations al AST y mejorar reporting de errores.

Entregables:
- `grammar.pegjs` estable.
- `parser.cjs/parser.js` generados en CI y opcionalmente incluidos en el repo.
- Documentación del AST (en `src/lib/star-parser/README.md`).

Riesgos:
- Cambios frecuentes en la gramática pueden romper tests; mitigación: job CI que valide compatibilidad.

Duración estimada: 1–3 sprints pequeños (2–6 semanas) dependiendo del alcance final.

