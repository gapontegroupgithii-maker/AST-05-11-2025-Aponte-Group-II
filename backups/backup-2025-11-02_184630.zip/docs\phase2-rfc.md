# Fase 2 — Parser / AST (RFC)

Resumen

- Objetivo: construir un parser fiable para Star Script (subconjunto de Pine v5) y emitir un AST estable que permita transformaciones (transpiler Pine↔Star, análisis, linting y runtime).
- Opciones principales:
  1. Mantener y extender el parser hand‑written (current implementation).
  2. Migrar o generar un parser con un generador (peggy) y mantener el hand‑written como fallback.

Requisitos mínimos

- Parsear asignaciones, llamadas (funciones), arrays, strings (con escapes), números, índices (close[1]), comentarios (line y block), y directivas `//@version`.
- Producir un AST simple y tipado (TypeScript) con nodos: Program, Assignment, Call, Identifier, Index, Array, String, Number, Binary.
- Tener test coverage para las construcciones críticas (unit tests con Vitest).
- Mantener velocidad razonable y trazabilidad de errores (source positions opcional en 2ª iteración).

Comparativa: hand‑written vs generated (peggy)

1) Hand‑written (actual)
- Pros:
  - Control fino sobre comportamiento, tolerancia a errores y heurísticas (útil para transición y corrección gradual).
  - No depende de herramientas externas en el dev environment.
  - Fácil de probar incrementos pequeños sin regenerar artefactos.
- Contras:
  - Crecimiento en complejidad con la gramática; cuesta mantener precedencia y ambigüedades.
  - Riesgo de bugs sutiles en parsing (precedencia, asociatividad, backtracking).
  - Más trabajo para soportar features avanzadas (posiciones, error reporting, recovery).

2) Parser generado (peggy)
- Pros:
  - Gramática declarativa centralizada; fácil de expresar precedencia y reglas complejas.
  - Mejor mantenimiento a medida que la gramática crece.
  - Herramienta probada y optimizada para parsing; puede generar código rápido.
- Contras:
  - Añade dependencia de build (peggy) y puede requerir Node toolchain en CI/dev.
  - Transición inicial para mantener paridad con el parser hand‑written (migración de tests/semántica).
  - Generación incremental y manejo de cambios en la gramática exige CI configurado (pero esto es deseable).

Propuesta híbrida (recomendada para ahora)

- Mantener el parser hand‑written como implementacion principal durante la iteración y el desarrollo local (ya está probado y cubierto por tests).
- Introducir una gramática `grammar.pegjs` (ya existe en `src/lib/star-parser/grammar.pegjs`) y configurar un job opcional en CI que ejecute `npm run build:parser` y valide que la gramática generada produce un AST compatible (tests de integración).
- Objetivo: poder validar la gramática generada sin romper el flujo actual; una vez la gramática sea madura, considerar reemplazar o unificar la implementación.

Plan de trabajo (sprints cortos)

1. (Hoy) RFC y job CI opcional — esto ya se crea y se prueba en rama `starscript/phase2-parser`.
2. Añadir tests faltantes: cadenas con escapes, operadores unarios, comentarios incrustados en arrays, llamadas con expresiones complejas.
3. Sincronizar `grammar.pegjs` con casos de tests; iterar hasta que la gramática genere ASTs compatibles en CI.
4. Evaluar rendimiento y ergonomía; si la gramática cubre >90% de los casos, preparar migración gradual.

Artifacts añadidos

- `src/lib/star-parser/grammar.pegjs` (ya presente) — punto de partida para generación.
- Job CI opcional (`.github/workflows/parser-gen.yml`) para ejecutar `npm run build:parser` y validar tests.

Riesgos y mitigaciones

- Dependencia de `peggy` en CI: añadir `peggy` como devDependency y ejecutar en un job separado; no forzar a los desarrolladores locales a instalarlo.
- Desajuste AST: escribir adaptadores para mapear AST generado a la forma actual; mantener tests que aseguren compatibilidad.

Aceptación

- Tests existentes siguen pasando.
- Job CI opcional puede ejecutar `npm run build:parser` y la generación no rompe la suite.

---

Fecha: 2025-11-01
Autor: Equipo Starscript (generado)
