# RFC: Fase 2 — Parser / AST para Star Script

Objetivo
-------
Crear un parser y representación AST para una sub-conjunto seguro y útil de Pine Script v5 (Star Script), que nos permita implementar transformaciones robustas y un runtime seguro en fases posteriores.

Alcance mínimo (MVP de parser)
-------------------------------
- Parsear declaraciones básicas: `indicator`, `strategy`, `study` (alias), `plot`, `plotshape`, `input.*`, `request.security`.
- Expresiones: literales (números, strings, booleans), arrays, identificadores, llamadas a funciones (con args posicionales y nombrados), accesos con índices (e.g., `close[1]`), propiedades (`obj.prop`).
- Sentencias: asignaciones simples (`x = expr`), condicionales `if`, return (para scripts tipo function/strategy), bloques `{}` opcionales.
- Comentarios y directivas (`//@version=5`, `//@some_meta`) preservadas en metadatos.

Herramienta recomendada
-----------------------
Recomiendo usar `peggy` (fork moderno de PEG.js) por:
- Sintaxis de gramática clara y robusta para lenguajes con ambigüedad controlada.
- Generación de un parser JS rápido y pequeño que funciona en navegador y Node.
- Buena comunidad y ejemplos para gramáticas de lenguajes de scripting.

Estructura propuesta
--------------------
- `src/lib/star-parser/grammar.pegjs` — gramática peggy.
- `src/lib/star-parser/index.ts` — wrapper TS que expone `parse(code): AST` y `transform(ast): AST`.
- `tests/parser/*` — tests unitarios con ejemplos Pine/Star y aserciones sobre AST.

Plan de trabajo (primeros pasos)
--------------------------------
1. Definir subset de tokens y expresiones (2–4h).
2. Escribir gramática inicial en `peggy` para sentencias y expresiones básicas (4–6h).
3. Integrar parser en el proyecto (loader en dev y build) y añadir tests (2–4h).
4. Reescribir partes del transpiler para usar AST en lugar de regex para transformaciones críticas (4–8h).

Medidas de seguridad y sandboxing
---------------------------------
- El parser y AST no deben ejecutar código.
- El runtime que luego interprete AST debe ejecutarse en un sandbox (WebWorker o iframe con políticas CSP) y limitar APIs disponibles.

Pruebas y cobertura
-------------------
- Tests para cada regla de gramática y transformaciones.
- Ejemplos reales de Pine Scripts de la carpeta `tests/star-examples/` para validar parsing y roundtrip (Pine -> AST -> Star -> Pine).

Siguientes pasos propuestos
--------------------------
- Si apruebas, creo el esqueleto del parser (`grammar.pegjs` inicial + wrapper TS) y 6 tests de parsing (MVP).

---

Fecha: 2025-10-31
Autor: Equipo Star Script (propuesta automática)
