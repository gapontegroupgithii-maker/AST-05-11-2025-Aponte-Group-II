# Star Script — Especificación (Phase 0)

Propósito
--------
Definir el contrato mínimo y el alcance para Star Script (gemelo de Pine v5) bajo el namespace `star.`. Este documento establece las prioridades, el mapping inicial y ejemplos para comenzar la Fase 1 (MVP Transpiler).

Alcance y principios
--------------------
- Baseline Pine v5 (subset conservador): declaraciones, asignaciones, llamadas a funciones, arrays, índices `[n]`, strings, números, comentarios y directiva `//@version`.
- Mantener compatibilidad semántica con Pine en los constructs críticos para indicadores y estrategias.
- Namespace principal: `star.` — todas las APIs expuestas por Star deben vivir ahí (por ejemplo `star.plot`, `star.ta.sma`, `star.request.security`).

Mapping inicial (reglas heurísticas)
-----------------------------------
- `plot(...)` -> `star.plot(...)`
- `ta.*` -> `star.ta.*` (por ejemplo `ta.sma` -> `star.ta.sma`)
- `color.rgb(...)` -> `star.color.rgb(...)`
- `input.*` -> `star.input.*`
- `indicator(...)` / `strategy(...)` -> `star.indicator(...)` / `star.strategy(...)` (o mapping a llamadas especiales según diseño)
- `request.security(...)` y variantes -> `star.request.security(...)` (preservar suffixes)
- Indexing: `close[1]` → se mantiene como `close[1]` (no se transforma a propiedad)

Lista de funciones iniciales (ejemplos)
------------------------------------
- star.plot
- star.ta.sma, star.ta.ema, star.ta.rsi (subset común)
- star.strategy.entry / star.strategy.exit (mapear estrategia básica)
- star.request.security
- star.input.number, star.input.string

Criterios de aceptación
-----------------------
- Documento `docs/star-spec.md` y 3 scripts de ejemplo en `tests/star-examples/` presentes en la rama `starscript/phase-0-spec`.
- Tests básicos de transpiler para los snippets de ejemplo (Fase 1) deben poder correr.

Scripts de prueba (ejemplos)
---------------------------
Se añaden 3 scripts de ejemplo en `tests/star-examples/` (indicados más abajo). Estos se usarán para validar el transpiler y parser:

1) `examples/indicator_example.pine` — indicador simple con `plot` y `ta.sma`.
2) `examples/strategy_example.pine` — estrategia básica con `strategy` y `plot`.
3) `examples/complex_example.pine` — uso de `request.security`, arrays y comentarios.

Notas operativas
----------------
- La rama de trabajo será `starscript/phase-0-spec`.
- Antes de editar se crea un backup (script `scripts/create_backup.ps1`).
- El repositorio mantiene el parser hand‑written y una gramática PEG opcional como fuentes de verdad.

Ejemplos añadidos
-----------------
Ver `tests/star-examples/` para los 3 scripts listos para pruebas.

Fecha: 2025-11-02
# Star Script — Especificación inicial (Fase 0)

Última actualización: 2025-10-30

Propósito
-------
Star Script es un lenguaje gemelo / compatible con Pine Script v5 (TradingView) orientado a uso privado en esta aplicación. El objetivo de la Fase 0 es definir el contrato mínimo, el namespace `star.` y los mapeos iniciales que permitiremos en la MVP.

Alcance (baseline)
------------------
- Compatibilidad objetivo: Pine Script v5 (baseline), centrado en indicadores y estrategias que usan llamadas comunes (`indicator`, `strategy`, `ta.*`, `plot`, `plotshape`, `input.*`, `request.security*`, arrays, indexación histórica `[n]`, `var`, `switch`, expresiones). 
- No se garantiza compatibilidad 100% en Fase 1 (MVP heurístico). Fase 2 (parser+AST) abordará cobertura completa.

Reglas globales / Namespace
--------------------------
- Todos los símbolos API expuestos por el runtime se agrupan bajo `star.`. Ejemplos:
  - `indicator(...)` → `star.indicator(...)`
  - `strategy(...)` → `star.strategy(...)`
  - `ta.sma(x, n)` → `star.ta.sma(x, n)`
  - `plot(x)` → `star.plot(x)`
  - `plotshape(cond, ...)` → `star.plotshape(cond, ...)`
  - `color.rgb(r,g,b,a?)` → `star.color.rgb(r,g,b,a?)`
  - `input(title, defval)` → `star.input(...)`
  - `request.security_lower_tf(...)` → `star.request.security_lower_tf(...)`
  - `syminfo.tickerid` → `star.syminfo.tickerid`
  - `timeframe.isseconds` → `star.timeframe.isseconds`

Convenciones sintácticas (MVP)
-----------------------------
- Mantendremos la sintaxis general de Pine v5 en los scripts; el transpiler añadirá `star.` a llamadas conocidas y mapeará identificadores dot-separated (`ta.`, `strategy.`, `request.`) a `star.`.
- Indexado histórico (`close[1]`, `ta.hma(close, 12)[2]`) se preserva tal cual. El runtime debe interpretar las referencias históricas correctamente.

Mapeo rápido (ejemplos)
-----------------------
- Pine: `indicator("My", overlay=true)`
- Star: `star.indicator("My", overlay=true)`

- Pine: `plot(ta.sma(close, 14), color=color.red)`
- Star: `star.plot(star.ta.sma(star.close, 14), { color: star.color.rgb(255,0,0) })`

- Pine: `var float x = na` → Star: `var float x = na` (variables siguien siendo variables; llamadas API se prefijan)

Seguridad y restricciones (resumen)
----------------------------------
- El runtime ejecutará scripts en un entorno sandbox (Web Worker o sandbox JS) con límites: timeout por ejecución, límite de iteraciones/recursión y ninguna capacidad de IO/Network por defecto.
- Solo las APIs `star.*` están expuestas; las funciones internas de la app (window, fetch, fs) estarán inaccesibles.

Tests y ejemplos
----------------
En `tests/star-examples/` incluiremos ejemplos que servirán como suite inicial de validación (MA simple, RSI, y un script de strategy más grande provisto por el usuario).

Contrato de aceptación para Fase 0
--------------------------------
- `docs/star-spec.md` revisado y aprobado por el usuario.
- 3 scripts de ejemplo añadidos a `tests/star-examples/`.

Notas
-----
- Esta especificación es un primer borrador (Fase 0). Tras tu validación avanzaremos a la Fase 1 (MVP transpiler heurístico).
