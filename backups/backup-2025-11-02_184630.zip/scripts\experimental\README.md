This folder contains experimental/temporary scripts used during parser development.

Files:
- `run_gen_parse.cjs` — ad-hoc CommonJS runner used locally to exercise the generated parser.
- other helpers used during grammar iteration.

These scripts are intended for local debugging and may be removed or moved to tests/ once stabilized.
