const gen = require('../src/lib/star-parser/parser.cjs');
try {
  console.log(JSON.stringify(gen.parse('close[1]\n'), null, 2));
} catch (e) {
  console.error(e && e.message ? e.message : e);
}
