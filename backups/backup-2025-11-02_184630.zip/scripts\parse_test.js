const gen = require('../src/lib/star-parser/parser.cjs');
const samples = [
  'a = close[1] + open\n',
  'indicator("myind")\na = max(close, sma(close, 14))\n',
  'a = [1, [2, 3], 4]\n',
  '/* block comment */\na = 2 // endline\n'
];

samples.forEach((s,i)=>{
  try {
    console.log('--- Sample', i, '---');
    console.log(JSON.stringify(gen.parse(s), null, 2));
  } catch (e) {
    console.error('Error parsing sample', i);
    console.error(e);
  }
});
