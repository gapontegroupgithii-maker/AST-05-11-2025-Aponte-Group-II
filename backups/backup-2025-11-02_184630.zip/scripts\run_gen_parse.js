const p = require('../src/lib/star-parser/parser.cjs');
const parse = p.parse || (p.default && p.default.parse);
const samples = [
  `a = close[1] + open\n`,
  `indicator("myind")\na = max(close, sma(close, 14))\n`,
  `a = [1, [2, 3], 4]\n`,
  `/* block comment */\na = 2 // endline\n`
];
for (let i=0;i<samples.length;i++){
  const s = samples[i];
  try{
    const out = parse(s);
    console.log('SAMPLE', i, JSON.stringify(out, null, 2));
  }catch(e){
    console.error('SAMPLE', i, 'ERROR', e && e.message);
  }
}
