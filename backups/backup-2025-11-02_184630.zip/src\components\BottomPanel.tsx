import { useState, useEffect } from "react";
import { ChevronUp, Code, BarChart3, ArrowLeftRight } from "lucide-react";
import { pineToStar, starToPine, validatePine } from "@/lib/star-transpiler";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from "@/components/ui/dialog";

interface BottomPanelProps {
  starScriptEditId?: string|null;
  starScriptContent?: string;
  setStarScriptContent?: (content: string) => void;
  onSaveStarScript?: (content: string) => void;
  onCloseStarScript?: () => void;
}

const BottomPanel = ({ starScriptEditId, starScriptContent, setStarScriptContent, onSaveStarScript, onCloseStarScript }: BottomPanelProps) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  useEffect(() => {
    // If a script is requested to edit, ensure panel is open
    if (starScriptEditId) setIsCollapsed(false);
  }, [starScriptEditId]);

  // Hooks must be declared unconditionally to preserve hook order
  const [activeTab, setActiveTab] = useState<string>("script");
  const [pineInput, setPineInput] = useState<string>("");
  const [starOutput, setStarOutput] = useState<string>("");
  const [showApplyConfirm, setShowApplyConfirm] = useState<boolean>(false);

  const handleTranslate = () => {
    const input = pineInput || "";
    // run quick validation first
    const result = validatePine(input);
    if (!result.valid) {
      setStarOutput("// Translation halted due to validation errors: " + result.errors.join('; '));
      return;
    }
    try {
      const out = pineToStar(input);
      setStarOutput(out);
    } catch (e) {
      setStarOutput("// Translation failed: " + String(e));
    }
  };

  const handleReverse = () => {
    try {
      const out = starToPine(starOutput || pineInput || "");
      setPineInput(out);
    } catch (e) {
      // ignore
    }
  };

  const applyToEditor = () => {
    // show confirmation modal before applying
    setShowApplyConfirm(true);
  };

  const confirmApply = (save: boolean) => {
    if (starOutput && setStarScriptContent) {
      setStarScriptContent(starOutput);
    }
    if (save && onSaveStarScript) {
      onSaveStarScript(starOutput || '');
    }
    setActiveTab("script");
    setShowApplyConfirm(false);
  };

  if (isCollapsed) {
    return (
      <div className="h-8 bg-panel-bg border-t border-border flex items-center justify-center">
        <Button
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0"
          onClick={() => setIsCollapsed(false)}
        >
          <ChevronUp className="w-4 h-4 rotate-180" />
        </Button>
      </div>
    );
  }

  return (
    <div className="h-64 bg-panel-bg border-t border-border flex flex-col shrink-0">
      {/* Collapse Button */}
      <div className="h-8 border-b border-border flex items-center justify-center shrink-0">
        <Button
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0"
          onClick={() => setIsCollapsed(true)}
        >
          <ChevronUp className="w-4 h-4" />
        </Button>
      </div>

      {/* Tabs */}
  <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v)} className="flex-1 flex flex-col">
        <TabsList className="w-full justify-start rounded-none bg-toolbar-bg border-b border-border h-10 shrink-0">
          <TabsTrigger value="script" className="gap-2">
            <Code className="w-4 h-4" />
            Star Script Editor
          </TabsTrigger>
          <TabsTrigger value="tester" className="gap-2">
            <BarChart3 className="w-4 h-4" />
            Strategy Tester
          </TabsTrigger>
          <TabsTrigger value="translator" className="gap-2">
            <ArrowLeftRight className="w-4 h-4" />
            Translator
          </TabsTrigger>
        </TabsList>

        <TabsContent value="script" className="flex-1 p-4 m-0 overflow-auto">
          <div className="space-y-2 h-full flex flex-col">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold">Star Script Editor</h3>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="h-7 text-xs">
                  Load Script
                </Button>
                <Button size="sm" className="h-7 text-xs">
                  Run on Chart
                </Button>
              </div>
            </div>
            <Textarea
              value={starScriptContent}
              onChange={e => setStarScriptContent?.(e.target.value)}
              placeholder="// Star Script - Identical to Pine Script v5\n// Use star() instead of strategy() or indicator()\n\n//@version=5\nstar('My Strategy', overlay=true)\n\n// Your trading logic here..."
              className="flex-1 font-mono text-xs bg-background border-border resize-none"
            />
            {starScriptEditId ? (
              <div className="flex gap-2 mt-2">
                <Button size="sm" variant="default" onClick={() => onSaveStarScript?.(starScriptContent || '')}>Guardar</Button>
                <Button size="sm" variant="ghost" onClick={() => onCloseStarScript?.()}>Cerrar</Button>
              </div>
            ) : null}
          </div>
        </TabsContent>
        {/* Apply confirmation dialog */}
        <Dialog open={showApplyConfirm} onOpenChange={setShowApplyConfirm}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Apply Star Script</DialogTitle>
              <DialogDescription>Are you sure you want to apply the converted Star Script to the editor? You can choose to apply only or apply and save.</DialogDescription>
            </DialogHeader>
            <div className="flex gap-2 mt-4">
              <Button size="sm" variant="default" onClick={() => confirmApply(false)}>Apply</Button>
              <Button size="sm" variant="destructive" onClick={() => confirmApply(true)}>Apply & Save</Button>
              <DialogClose asChild>
                <Button size="sm" variant="outline" onClick={() => setShowApplyConfirm(false)}>Cancel</Button>
              </DialogClose>
            </div>
          </DialogContent>
        </Dialog>

        <TabsContent value="tester" className="flex-1 p-4 m-0 overflow-auto">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold">Strategy Tester</h3>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="h-7 text-xs">
                  Configure
                </Button>
                <Button size="sm" className="h-7 text-xs">
                  Start Backtest
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-secondary rounded p-3">
                <div className="text-xs text-muted-foreground mb-1">Total Profit</div>
                <div className="text-lg font-bold text-bullish">+0.00%</div>
              </div>
              <div className="bg-secondary rounded p-3">
                <div className="text-xs text-muted-foreground mb-1">Win Rate</div>
                <div className="text-lg font-bold">0.00%</div>
              </div>
              <div className="bg-secondary rounded p-3">
                <div className="text-xs text-muted-foreground mb-1">Max Drawdown</div>
                <div className="text-lg font-bold text-bearish">0.00%</div>
              </div>
              <div className="bg-secondary rounded p-3">
                <div className="text-xs text-muted-foreground mb-1">Trades</div>
                <div className="text-lg font-bold">0</div>
              </div>
            </div>

            <p className="text-xs text-muted-foreground">
              Run a Star Script strategy to see backtest results here.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="translator" className="flex-1 p-4 m-0 overflow-auto">
          <div className="space-y-4 h-full flex flex-col">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold">Bidirectional Translator</h3>
              <div className="flex gap-2">
                <Button size="sm" className="h-7 text-xs" onClick={handleTranslate}>Translate</Button>
                <Button size="sm" variant="outline" className="h-7 text-xs" onClick={handleReverse}>Reverse</Button>
                <Button size="sm" className="h-7 text-xs" onClick={applyToEditor}>Apply to Editor</Button>
              </div>
            </div>

            <div className="flex-1 grid grid-cols-2 gap-4">
              <div className="space-y-2 flex flex-col">
                <label className="text-xs font-medium">Pine Script Input</label>
                <Textarea
                  value={pineInput}
                  onChange={(e) => setPineInput(e.target.value)}
                  placeholder="// Paste Pine Script code here..."
                  className="h-full font-mono text-xs bg-background border-border resize-none"
                />
              </div>
              <div className="space-y-2 flex flex-col">
                <label className="text-xs font-medium">Star Script Output</label>
                <Textarea
                  value={starOutput}
                  onChange={(e) => setStarOutput(e.target.value)}
                  placeholder="// Converted Star Script will appear here..."
                  className="h-full font-mono text-xs bg-background border-border resize-none"
                />
              </div>
            </div>
            <div className="pt-2">
              {/* Validation / status area */}
              {pineInput ? (() => {
                const v = validatePine(pineInput);
                return v.valid ? (
                  <div className="text-xs text-success">Pine input OK</div>
                ) : (
                  <div className="text-xs text-rose-500">Validation errors: {v.errors.join('; ')}</div>
                );
              })() : null}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BottomPanel;
