# star-parser

Este directorio contiene la gramática PEG (para generar un parser con Peggy) y el parser hecho a mano usado como fallback.

Propósito
- Mantener un parser robusto y reproducible para Star Script (gemelo de Pine v5).
- Permitir generación automática del parser con Peggy y validar que el parser generado produce el mismo AST que el parser escrito a mano.

Archivos clave
- `grammar.pegjs` - Gramática PEG utilizada para generar `parser.cjs / parser.js` con `peggy`.
- `parser.cjs`, `parser.js` - Parsers generados (CJS/UMD) por `peggy` para compatibilidad local/CI.
- `index.ts` - Parser escrito a mano (implementación principal por ahora). Exporta `parse(code:string)`.

Contrato del AST (forma esperada)
- Root: { version: string|null, indicators: Array<{ type: 'indicator' | 'strategy', name?: string }>, assignments: Array<{ id: string, expr: Expression }> }

- Expression (posibles tipos):
  - { type: 'String', value: string }
  - { type: 'Number', value: number }
  - { type: 'Identifier', name: string }
  - { type: 'Index', base: string, index: number }
  - { type: 'Array', items: Expression[] }
  - { type: 'Call', callee: string, args: Expression[] }
  - { type: 'Binary', operator: string, left: Expression, right: Expression }

Cómo regenerar el parser (local)

1. Instalar peggy si no está presente (usa npx para instalación temporal):

```powershell
npx peggy -V
```

2. Generar artefactos:

```powershell
npx peggy -o src/lib/star-parser/parser.cjs src/lib/star-parser/grammar.pegjs
npx peggy -o src/lib/star-parser/parser.js src/lib/star-parser/grammar.pegjs
```

3. Ejecutar tests para validar compatibilidad entre el parser generado y el parser escrito a mano:

```powershell
npm test
```

CI
- Hay un workflow opcional en `.github/workflows/parser-gen.yml` que ejecutará la generación del parser y la suite de tests en GitHub Actions para ramas `starscript/**`.

Notas
- Mantenemos el parser escrito a mano como referencia y respaldo; la gramática PEG y el parser generado deben mantenerse en compatibilidad mediante el test `tests/parser/generated-compat.test.ts`.
- Si actualizas la gramática, ejecuta la regeneración y corre los tests localmente antes de push.

Contacto
- Para dudas sobre la gramática o compatibilidad del AST, abrir issue en el repo o contactar al equipo que mantiene `starscript/phase2-peggy-integration`.
