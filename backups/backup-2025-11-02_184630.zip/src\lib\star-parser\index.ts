// Hand-written recursive-descent parser for a conservative Pine subset.
// This parser avoids external deps so it can run offline and provides a
// robust AST for the transformations in Phase 2.

export type AST = {
  version?: string | null;
  indicators: Array<{ type: 'indicator' | 'strategy'; name?: string }>;
  assignments: Array<{ id: string; expr: Expression }>;
};

export type Expression =
  | { type: 'String'; value: string }
  | { type: 'Number'; value: number }
  | { type: 'Identifier'; name: string }
  | { type: 'Index'; base: string; index: number }
  | { type: 'Array'; items: Expression[] }
  | { type: 'Call'; callee: string; args: Expression[] }
  | { type: 'Binary'; operator: string; left: Expression; right: Expression };

class Parser {
  code: string;
  pos: number;
  len: number;

  constructor(code: string) {
    this.code = code || '';
    this.pos = 0;
    this.len = this.code.length;
  }

  eof() {
    return this.pos >= this.len;
  }

  peek(n = 0) {
    return this.code[this.pos + n];
  }

  consumeWhile(fn: (ch: string) => boolean) {
    const start = this.pos;
    while (!this.eof() && fn(this.peek())) this.pos++;
    return this.code.slice(start, this.pos);
  }

  skipWhitespace() {
    this.consumeWhile(ch => ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n');
  }

  match(re: RegExp) {
    const m = re.exec(this.code.slice(this.pos));
    if (m && m.index === 0) {
      this.pos += m[0].length;
      return m;
    }
    return null;
  }

  parseProgram(): AST {
    const ast: AST = { version: null, indicators: [], assignments: [] };
    while (!this.eof()) {
      // First skip raw whitespace but keep comments so we can detect //@version directives
      this.skipWhitespace();
      if (this.eof()) break;
      if (this.code.startsWith('//@version', this.pos)) {
        const v = this.parseVersionDirective();
        if (v) ast.version = v;
        continue;
      }
      // Now skip comments and remaining whitespace before parsing statements
      this.skipWhitespaceAndComments();
      if (this.eof()) break;

      // Try parse assignment or function call
      const save = this.pos;
      const id = this.parseIdentifierText();
      if (id) {
        this.skipWhitespace();
        const ch = this.peek();
        if (ch === '=') {
          this.pos++; // consume '='
          this.skipWhitespace();
          const expr = this.parseExpression();
          // consume until end of line
          this.consumeWhile(c => c !== '\n');
          ast.assignments.push({ id, expr });
          continue;
        }
        if (ch === '(') {
          // function call
          const call = this.parseCallAt(id);
          if (call) {
            if (call.callee === 'indicator' || call.callee === 'strategy') {
              // try capture name from first string argument
              const typ = (call.callee === 'indicator' ? 'indicator' : 'strategy') as 'indicator' | 'strategy';
              let name: string | undefined = undefined;
              if (Array.isArray(call.args)) {
                const firstStr = call.args.find(a => a.type === 'String');
                if (firstStr && firstStr.type === 'String') name = firstStr.value;
              }
              ast.indicators.push({ type: typ, name });
            }
            continue;
          }
        }
      }

      // If nothing matched, skip a line to avoid infinite loops
      this.pos = save;
      this.consumeWhile(c => c !== '\n');
      if (this.peek() === '\n') this.pos++;
    }
    return ast;
  }

  skipWhitespaceAndComments() {
    while (!this.eof()) {
      if (this.peek() === '/' && this.peek(1) === '/') {
        // line comment
        this.consumeWhile(c => c !== '\n');
        if (this.peek() === '\n') this.pos++;
        continue;
      }
      if (this.peek() === '/' && this.peek(1) === '*') {
        // block comment
        this.pos += 2;
        while (!this.eof() && !(this.peek() === '*' && this.peek(1) === '/')) this.pos++;
        if (this.peek() === '*' && this.peek(1) === '/') this.pos += 2;
        continue;
      }
      if (/\s/.test(this.peek())) {
        this.skipWhitespace();
        continue;
      }
      break;
    }
  }

  parseVersionDirective(): string | null {
    const m = this.match(/^\/\/@version\s*=\s*([0-9]+)/);
    if (m) return m[1];
    return null;
  }

  parseIdentifierText(): string | null {
    const m = this.match(/^[a-zA-Z_][a-zA-Z0-9_.]*/);
    return m ? m[0] : null;
  }

  parseCallAt(name: string): { callee: string; args: Expression[] } | null {
    // assume current pos is at '('
    this.skipWhitespace();
    if (this.peek() !== '(') return null;
    this.pos++; // consume '('
    const args = this.parseCallArgs();
    // consume optional rest of line
    this.consumeWhile(c => c !== '\n');
    if (this.peek() === '\n') this.pos++;
    return { callee: name, args };
  }

  parseCallArgs(): Expression[] {
    const items: Expression[] = [];
    while (!this.eof()) {
      this.skipWhitespace();
      if (this.peek() === ')') {
        this.pos++; // consume ')'
        break;
      }
      const expr = this.parseExpression();
      items.push(expr);
      this.skipWhitespace();
      if (this.peek() === ',') {
        this.pos++; // consume ',' and continue
        continue;
      }
    }
    return items;
  }

  parseExpression(): Expression {
    this.skipWhitespace();
    const ch = this.peek();
    let left: Expression;
    if (ch === '"') {
      left = this.parseString();
    } else if (/[0-9]/.test(ch)) {
      left = this.parseNumber();
    } else if (ch === '[') {
      left = this.parseArray();
    } else {
      // identifier or indexed identifier
      const id = this.parseIdentifierText();
      if (id) {
        this.skipWhitespace();
        if (this.peek() === '[') {
          this.pos++; // consume '['
          const numMatch = this.match(/^[0-9]+/);
          const num = numMatch ? parseInt(numMatch[0]) : 0;
          this.consumeWhile(c => c !== ']');
          if (this.peek() === ']') this.pos++;
          left = { type: 'Index', base: id, index: num };
        } else if (this.peek() === '(') {
          const call = this.parseCallAt(id);
          if (call) left = { type: 'Call', callee: call.callee, args: call.args };
          else left = { type: 'Identifier', name: id };
        } else {
          left = { type: 'Identifier', name: id };
        }
      } else {
        const raw = this.consumeWhile(c => !/\s|,|\)|\]|\}/.test(c));
        left = { type: 'Identifier', name: raw };
      }
    }

    this.skipWhitespace();
    // handle binary operators (left-associative, attempts to allow right-side parsing)
    while (!this.eof()) {
      const op = this.peek();
      if (!op || !/[+\-*/]/.test(op)) break;
      // if this is the start of a comment '//' or '/*', stop parsing operators here
      if (op === '/' && (this.peek(1) === '/' || this.peek(1) === '*')) break;
      this.pos++; // consume operator
      this.skipWhitespace();
      const right = this.parseExpression();
      left = { type: 'Binary', operator: op, left, right };
      this.skipWhitespace();
    }
    return left;
  }

  parseString(): Expression {
    // assume starting at '"'
    this.pos++; // consume '"'
    let out = '';
    while (!this.eof()) {
      const ch = this.peek();
      if (ch === '"') {
        this.pos++;
        break;
      }
      if (ch === '\\') {
        this.pos++;
        const esc = this.peek();
        out += esc;
        this.pos++;
        continue;
      }
      out += ch;
      this.pos++;
    }
    return { type: 'String', value: out };
  }

  parseNumber(): Expression {
    const m = this.match(/^[0-9]+(\.[0-9]+)?/);
    return { type: 'Number', value: m ? parseFloat(m[0]) : 0 };
  }

  parseArray(): Expression {
    // consume '['
    this.pos++;
    const items: Expression[] = [];
    while (!this.eof()) {
      this.skipWhitespace();
      if (this.peek() === ']') {
        this.pos++;
        break;
      }
      const expr = this.parseExpression();
      items.push(expr);
      this.skipWhitespace();
      if (this.peek() === ',') {
        this.pos++;
        continue;
      }
    }
    return { type: 'Array', items };
  }
}

export function parse(code: string): AST {
  const p = new Parser(code || '');
  return p.parseProgram();
}

export default { parse };
