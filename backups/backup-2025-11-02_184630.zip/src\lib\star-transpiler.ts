// star-transpiler.ts
// Scaffold inicial para el transpiler heurístico Pine -> Star y Star -> Pine

export function pineToStar(code: string): string {
  // Reglas muy simples y seguras: prefijar llamadas conocidas con `star.`
  let out = code;

  // Prefijar indicator/strategy (solo primeras ocurrencias simples)
  out = out.replace(/\bindicator\s*\(/g, 'star.indicator(');
  out = out.replace(/\bstrategy\s*\(/g, 'star.strategy(');

  // Prefijar ta. namespace -> star.ta. (no doble prefijo si ya es star.ta.)
  out = out.replace(/(?<!star\.)\bta\./g, 'star.ta.');

  // Prefijar plot/plotshape/color/input/request/array/syminfo/timeframe
  // Prefix common functions/namespaces, avoid double-prefixing when already star.*
  out = out.replace(/(?<!star\.)\bplot\s*\(/g, 'star.plot(');
  out = out.replace(/(?<!star\.)\bplotshape\s*\(/g, 'star.plotshape(');
  out = out.replace(/(?<!star\.)\bcolor\./g, 'star.color.');
  out = out.replace(/(?<!star\.)\binput\s*\(/g, 'star.input(');
  out = out.replace(/(?<!star\.)\brequest\./g, 'star.request.');
  out = out.replace(/(?<!star\.)\bsyminfo\./g, 'star.syminfo.');
  out = out.replace(/(?<!star\.)\btimeframe\./g, 'star.timeframe.');

  // Map color.rgb(...) occurrences more robustly (keep args)
  out = out.replace(/(?<!star\.)color\.rgb\s*\(([^)]+)\)/g, 'star.color.rgb($1)');

  // Map bare series identifiers (open/high/low/close/volume) to star.*
  // Avoid replacing object property accesses (e.g. obj.open) and avoid double-prefixing
  // Support optional index access like close[1] and array literals containing series
  out = out.replace(/(?<!\.|star\.)\b(open|high|low|close|volume)(\s*\[\s*\d+\s*\])?/g, (_m, p1, p2) => {
    return `star.${p1}${p2 || ''}`;
  });

  // Map input types like input.int / input.bool / input.timeframe (prefix namespace)
  out = out.replace(/(?<!star\.)\binput\.(int|float|bool|string|timeframe)\s*\(/g, 'star.input.$1(');

  // Map other input.* variants (timeframe/session/defval) safely
  out = out.replace(/(?<!star\.)\binput\.(timeframe|session|defval)\s*\(/g, 'star.input.$1(');

  // Map request.security_lower_tf and request.security calls
  out = out.replace(/(?<!star\.)request\.security_lower_tf\s*\(/g, 'star.request.security_lower_tf(');
  out = out.replace(/(?<!star\.)request\.security\s*\(/g, 'star.request.security(');

  // Map color.new(...) -> star.color.new(...)
  out = out.replace(/(?<!star\.)color\.new\s*\(/g, 'star.color.new(');

  // Handle nested color expressions: convert inner color.rgb/new first
  // e.g. color.new(color.rgb(...), 60) -> star.color.new(star.color.rgb(...), 60)
  out = out.replace(/color\.new\s*\(([^)]+)\)/g, (m) => {
    if (m.includes('star.color')) return m; // already converted
    let inner = m;
    inner = inner.replace(/color\.rgb\s*\(([^)]+)\)/g, 'star.color.rgb($1)');
    inner = inner.replace(/color\.new\s*\(/g, 'star.color.new(');
    inner = inner.replace(/color\.(\w+)/g, 'star.color.$1');
    return inner;
  });

  // Ensure variants are prefixed (these patterns are idempotent)
  out = out.replace(/(?<!star\.)request\.security\s*\(/g, 'star.request.security(');
  out = out.replace(/(?<!star\.)request\.security_lower_tf\s*\(/g, 'star.request.security_lower_tf(');

  // Nota: esto es un primer paso. Las transformaciones más complejas vendrán con AST.
  return out;
}

export function validatePine(code: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  if (!code || code.trim().length === 0) {
    errors.push('Input is empty');
    return { valid: false, errors };
  }

  // Disallow suspicious tags
  if (/<\/?\s*script\b/i.test(code)) {
    errors.push('Suspicious <script> tag detected');
  }

  // Basic length guard
  if (code.length > 20000) {
    errors.push('Input too large');
  }

  // Balanced braces/parentheses/brackets
  const pairs: Record<string, string> = { '(': ')', '[': ']', '{': '}' };
  const stack: string[] = [];
  for (let i = 0; i < code.length; i++) {
    const ch = code[i];
    if (ch === '(' || ch === '[' || ch === '{') stack.push(ch);
    if (ch === ')' || ch === ']' || ch === '}') {
      const last = stack.pop();
      if (!last || pairs[last] !== ch) {
        errors.push(`Unbalanced ${ch} at pos ${i}`);
        break;
      }
    }
  }
  if (stack.length > 0) errors.push('Unbalanced opening bracket(s)');

  return { valid: errors.length === 0, errors };
}

export function starToPine(code: string): string {
  let out = code;
  out = out.replace(/\bstar\.indicator\s*\(/g, 'indicator(');
  out = out.replace(/\bstar\.strategy\s*\(/g, 'strategy(');
  out = out.replace(/\bstar\.ta\./g, 'ta.');
  out = out.replace(/\bstar\.plot\s*\(/g, 'plot(');
  out = out.replace(/\bstar\.plotshape\s*\(/g, 'plotshape(');
  out = out.replace(/\bstar\.color\./g, 'color.');
  out = out.replace(/\bstar\.input\s*\(/g, 'input(');
  out = out.replace(/\bstar\.request\./g, 'request.');
  out = out.replace(/\bstar\.syminfo\./g, 'syminfo.');
  out = out.replace(/\bstar\.timeframe\./g, 'timeframe.');
  // Reverse series mapping: star.close -> close
  out = out.replace(/\bstar\.(open|high|low|close|volume)\b/g, '$1');
  return out;
}

export default {
  pineToStar,
  starToPine,
};
