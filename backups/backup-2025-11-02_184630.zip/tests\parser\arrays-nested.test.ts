import { describe, it, expect } from 'vitest'
import { parse } from '../../src/lib/star-parser'

describe('star-parser nested arrays', () => {
  it('parses nested arrays correctly', () => {
    const code = `a = [1, [2, 3], 4]\n`;
    const ast = parse(code);
    const a = ast.assignments.find(x => x.id === 'a');
    expect(a).toBeDefined();
    expect(a!.expr.type).toBe('Array');
    const arr = a!.expr as any;
    expect(arr.items).toHaveLength(3);
    expect(arr.items[0].type).toBe('Number');
    expect((arr.items[0] as any).value).toBe(1);
    expect(arr.items[1].type).toBe('Array');
    const inner = arr.items[1] as any;
    expect(inner.items[0].type).toBe('Number');
    expect((inner.items[0] as any).value).toBe(2);
  });
});
