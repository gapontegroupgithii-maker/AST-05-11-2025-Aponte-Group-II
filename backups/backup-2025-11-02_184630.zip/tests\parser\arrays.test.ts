import { describe, it, expect } from 'vitest'
import { parse } from '../../src/lib/star-parser'

describe('star-parser arrays', () => {
  it('parses array literal in assignment', () => {
    const code = `arr = [1, 2, close]\n`;
    const ast = parse(code);
    const arr = ast.assignments.find(x => x.id === 'arr');
    expect(arr).toBeDefined();
    expect(arr!.expr.type).toBe('Array');
    const items = (arr!.expr as any).items;
    expect(items.length).toBe(3);
    expect(items[0].type).toBe('Number');
    expect(items[1].type).toBe('Number');
    expect(items[2].type).toBe('Identifier');
    expect(items[2].name).toBe('close');
  });
});
