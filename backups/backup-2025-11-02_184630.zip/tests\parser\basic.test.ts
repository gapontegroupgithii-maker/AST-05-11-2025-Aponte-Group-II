import { describe, it, expect } from 'vitest'
import { parse } from '../../src/lib/star-parser'

describe('minimal star-parser parse', () => {
  it('extracts version and indicator name', () => {
    const code = `//@version=5\nindicator("MyInd", overlay=true)\nlen = input.int(14)`;
    const ast = parse(code);
    expect(ast.version).toBe('5');
    expect(ast.indicators.length).toBeGreaterThan(0);
    expect(ast.indicators[0].name).toBe('MyInd');
    expect(ast.assignments.some(a => a.id === 'len')).toBe(true);
  });
});
