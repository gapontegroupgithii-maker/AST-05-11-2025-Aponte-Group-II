import { describe, it, expect } from 'vitest'
import { parse } from '../../src/lib/star-parser'

describe('star-parser binary precedence', () => {
  it('parses 1 + 2 * 3 as 1 + (2 * 3)', () => {
    const code = `a = 1 + 2 * 3\n`;
    const ast = parse(code);
    const a = ast.assignments.find(x => x.id === 'a');
    expect(a).toBeDefined();
    expect(a!.expr.type).toBe('Binary');
    const top = a!.expr as any;
    expect(top.operator).toBe('+');
    expect(top.left.type).toBe('Number');
    expect((top.left as any).value).toBe(1);
    expect(top.right.type).toBe('Binary');
    const right = top.right as any;
    expect(right.operator).toBe('*');
    expect((right.left as any).value).toBe(2);
    expect((right.right as any).value).toBe(3);
  });
});
