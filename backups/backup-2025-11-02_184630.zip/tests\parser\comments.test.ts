import { describe, it, expect } from 'vitest'
import { parse } from '../../src/lib/star-parser'

describe('star-parser comments handling', () => {
  it('ignores block and line comments', () => {
    const code = `/* block comment */\na = 2 // endline comment\n`;
    const ast = parse(code);
    const a = ast.assignments.find(x => x.id === 'a');
    expect(a).toBeDefined();
    expect(a!.expr.type).toBe('Number');
    expect((a!.expr as any).value).toBe(2);
  });
});
