import { describe, it, expect } from 'vitest'
import { parse } from '../../src/lib/star-parser'

describe('star-parser expressions', () => {
  it('parses indexed series in assignment', () => {
    const code = `a = close[1] + open\n`;
    const ast = parse(code);
    const a = ast.assignments.find(x => x.id === 'a');
    expect(a).toBeDefined();
    // top-level should be a Binary (close[1] + open)
    expect(a!.expr.type).toBe('Binary');
    const top = a!.expr as any;
    expect(top.left.type).toBe('Index');
    const idx = top.left as any;
    expect(idx.base).toBe('close');
    expect(idx.index).toBe(1);
  });

  it('parses identifier expression when no index', () => {
    const code = `b = volume\n`;
    const ast = parse(code);
    const b = ast.assignments.find(x => x.id === 'b');
    expect(b).toBeDefined();
    expect(b!.expr.type).toBe('Identifier');
    const id = b!.expr as any;
    expect(id.name).toBe('volume');
  });
});
