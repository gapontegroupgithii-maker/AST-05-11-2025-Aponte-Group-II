import { describe, it, expect } from 'vitest'
import fs from 'fs'
import path from 'path'
import { parse as handParse } from '../../src/lib/star-parser'
import { createRequire } from 'module'

function normalize(obj: any): any {
  return JSON.parse(JSON.stringify(obj, (k, v) => {
    if (k === 'loc' || k === 'location' || k === 'start' || k === 'end') return undefined;
    return v;
  }));
}

describe('generated parser compatibility', () => {
  const genCandidates = [
    path.resolve(__dirname, '../../src/lib/star-parser/parser.cjs'),
    path.resolve(__dirname, '../../src/lib/star-parser/parser.js'),
  ];
  const genPath = genCandidates.find(p => fs.existsSync(p));
  if (!genPath) {
    it('skips when generated parser is not present', () => {
      // If peggy hasn't generated parser locally, skip this test (CI will generate it)
      expect(true).toBe(true);
    });
    return;
  }

  async function loadGenParse() {
    const genPathNonNull = genPath as string;
    if (genPathNonNull.endsWith('.cjs')) {
      const req = createRequire(import.meta.url);
      const g = req(genPathNonNull);
      return g && (g.parse || (g.default && g.default.parse));
    }
    const g = await import(genPathNonNull);
    return g && (g.parse || (g.default && g.default.parse));
  }

  const samples = [
    `a = close[1] + open\n`,
    `indicator("myind")\na = max(close, sma(close, 14))\n`,
    `a = [1, [2, 3], 4]\n`,
    `/* block comment */\na = 2 // endline\n`
  ];

  samples.forEach((s, i) => {
    it(`generated parser matches hand parser for sample ${i}`, async () => {
      const genParse = await loadGenParse();
      expect(genParse).toBeDefined();
      const a = handParse(s as string);
      const b = genParse(s as string);
      expect(normalize(a)).toEqual(normalize(b));
    });
  });

});
