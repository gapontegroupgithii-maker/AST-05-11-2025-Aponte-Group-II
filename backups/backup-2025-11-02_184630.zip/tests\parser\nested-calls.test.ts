import { describe, it, expect } from 'vitest'
import { parse } from '../../src/lib/star-parser'

describe('star-parser nested calls', () => {
  it('parses nested call as argument', () => {
    const code = `indicator("myind")\na = max(close, sma(close, 14))\n`;
    const ast = parse(code);
    const a = ast.assignments.find(x => x.id === 'a');
    expect(a).toBeDefined();
    expect(a!.expr.type).toBe('Call');
    const call = a!.expr as any;
    expect(call.callee).toBe('max');
    expect(call.args).toHaveLength(2);
    expect(call.args[0].type).toBe('Identifier');
    expect((call.args[0] as any).name).toBe('close');
    expect(call.args[1].type).toBe('Call');
    const inner = call.args[1] as any;
    expect(inner.callee).toBe('sma');
    expect(inner.args[0].type).toBe('Identifier');
    expect((inner.args[1] as any).type).toBe('Number');
    expect((inner.args[1] as any).value).toBe(14);
  });
});
