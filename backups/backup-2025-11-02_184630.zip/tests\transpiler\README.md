Transpiler tests

Aquí añadiremos snippets y tests unitarios para validar `src/lib/star-transpiler.ts`.

Actualmente el archivo es scaffold y se recomienda añadir tests que verifiquen:
- Prefijado de `indicator`/`strategy` -> `star.`
- Mapping de `ta.` -> `star.ta.`
- Mapping de `plot`, `plotshape`, `color`, `input`, `request`.
