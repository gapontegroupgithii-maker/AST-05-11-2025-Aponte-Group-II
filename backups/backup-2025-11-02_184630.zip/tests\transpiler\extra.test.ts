import { describe, it, expect } from 'vitest';
import { pineToStar } from '@/lib/star-transpiler';

describe('star-transpiler extra heuristics', () => {
  it('maps series identifiers to star.* preserving property accesses', () => {
    const pine = `
// use series
plot(open)
plot(close)
// object property should not change
obj.open
`;
    const out = pineToStar(pine);
    expect(out).toContain('plot(star.open)');
    expect(out).toContain('plot(star.close)');
    expect(out).toContain('obj.open');
  });

  it('prefixes request.security and preserves additional args', () => {
    const pine = `
res = request.security(syminfo.tickerid, timeframe.period, close, gaps=true)
`;
    const out = pineToStar(pine);
    expect(out).toContain('star.request.security(');
    expect(out).toContain('gaps=true');
  });

  it('keeps array literals intact', () => {
    const pine = `
arr = [1, 2, 3]
plot(arr[1])
`;
    const out = pineToStar(pine);
    expect(out).toContain('[1, 2, 3]');
    expect(out).toContain('plot(arr[1])');
  });
});
