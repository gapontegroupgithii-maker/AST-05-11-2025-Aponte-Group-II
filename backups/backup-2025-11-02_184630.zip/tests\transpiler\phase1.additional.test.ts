import { describe, it, expect } from 'vitest'
import { pineToStar } from '../../src/lib/star-transpiler'

describe('star-transpiler phase1 (indices, arrays, request)', () => {
  it('maps series with index like close[1]', () => {
    const pine = `plot(close[1])`;
    const out = pineToStar(pine);
    expect(out).toContain('plot(star.close[1])');
  });

  it('maps series inside array literals but keeps array indexing', () => {
    const pine = `arr = [open, close]\nplot(arr[0])`;
    const out = pineToStar(pine);
    expect(out).toContain('[star.open, star.close]');
    expect(out).toContain('plot(arr[0])');
  });

  it('prefixes request.security and preserves named args and nested calls', () => {
    const pine = `val = request.security(syminfo.tickerid, 'D', close, gaps=true)`;
    const out = pineToStar(pine);
    expect(out).toContain('star.request.security(');
    expect(out).toContain('gaps=true');
  });

  it('does not change object property accesses like obj.close or obj.open[1]', () => {
    const pine = `obj.close\nobj.open[1]`;
    const out = pineToStar(pine);
    expect(out).toContain('obj.close');
    expect(out).toContain('obj.open[1]');
  });
});
