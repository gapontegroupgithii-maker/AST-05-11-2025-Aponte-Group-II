import { describe, it, expect } from 'vitest'
import { pineToStar, starToPine } from '../../src/lib/star-transpiler'

describe('star-transpiler phase1 additional cases', () => {
  it('converts nested color.new(color.rgb(...), alpha)', () => {
    const pine = `plot(close, color=color.new(color.rgb(10,20,30), 80))`;
    const out = pineToStar(pine);
    expect(out).toContain('star.color.new(');
    expect(out).toContain('star.color.rgb(10,20,30)');
  });

  it('maps input.timeframe and input.session variants', () => {
    const pine = `tf = input.timeframe('5m')\ns = input.session('0000-2359')`;
    const out = pineToStar(pine);
    expect(out).toContain('star.input.timeframe(');
    expect(out).toContain('star.input.session(');
  });

  it('starToPine reverses series and color mappings', () => {
    const star = `star.plot(star.ta.sma(star.close,14), { color: star.color.rgb(1,2,3) })`;
    const pine = starToPine(star);
    expect(pine).toContain('plot(');
    expect(pine).toContain('color.rgb(1,2,3)');
    expect(pine).toContain('ta.sma');
  });
});
