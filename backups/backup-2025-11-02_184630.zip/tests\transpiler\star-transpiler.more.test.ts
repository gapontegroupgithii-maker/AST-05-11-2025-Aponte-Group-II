import { describe, it, expect } from 'vitest'
import { pineToStar, starToPine } from '../../src/lib/star-transpiler'

describe('star-transpiler (additional rules)', () => {
  it('maps color.rgb and color.new', () => {
    const pine = `plot(ta.sma(close,14), color=color.rgb(255, 0, 0))\nplot(close, color=color.new(color.blue, 60))`
    const out = pineToStar(pine)
    expect(out).toContain('star.color.rgb(255, 0, 0)')
    expect(out).toContain('star.color.new(star.color.blue, 60)')
  })

  it('maps input types and request.security', () => {
    const pine = `len = input.int(14, title="Len")\nuseCustom = input.bool(false)\nvals = request.security_lower_tf(syminfo.tickerid, '1', close)`
    const out = pineToStar(pine)
    expect(out).toContain('star.input.int(')
    expect(out).toContain('star.input.bool(')
    expect(out).toContain('star.request.security_lower_tf(')
  })

  it('starToPine reverts color mapping', () => {
    const starCode = `star.plot(star.ta.sma(close,14), { color: star.color.rgb(255,0,0) })`;
    const pine = starToPine(starCode)
    expect(pine).toContain('plot(')
    expect(pine).toContain('color.rgb(255,0,0)')
  })
})
