import { describe, it, expect } from 'vitest'
import { pineToStar, starToPine } from '../../src/lib/star-transpiler'

describe('star-transpiler (basic)', () => {
  it('prefixes indicator and ta namespace', () => {
    const pine = `//@version=5\nindicator("My", overlay=true)\nplot(ta.sma(close, 14))`
    const star = pineToStar(pine)
    expect(star).toContain('star.indicator(')
    expect(star).toContain('star.ta.sma')
    expect(star).toContain('star.plot(')
  })

  it('reverts star to pine', () => {
    const starCode = `star.indicator("X")\nstar.plot(star.ta.sma(close,14))`
    const pine = starToPine(starCode)
    expect(pine).toContain('indicator(')
    expect(pine).toContain('ta.sma')
    expect(pine).toContain('plot(')
  })
})
