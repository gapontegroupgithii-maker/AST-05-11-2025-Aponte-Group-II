import { describe, it, expect } from 'vitest'
import { validatePine } from '../../src/lib/star-transpiler'

describe('pine validation', () => {
  it('rejects empty input', () => {
    const r = validatePine('');
    expect(r.valid).toBe(false);
    expect(r.errors).toContain('Input is empty');
  });

  it('detects unbalanced parentheses', () => {
    const r = validatePine('plot(close(');
    expect(r.valid).toBe(false);
    expect(r.errors.some(e => /Unbalanced/.test(e))).toBe(true);
  });

  it('accepts simple valid pine', () => {
    const r = validatePine("//@version=5\nplot(close, color=color.rgb(1,2,3))");
    expect(r.valid).toBe(true);
  });
});
